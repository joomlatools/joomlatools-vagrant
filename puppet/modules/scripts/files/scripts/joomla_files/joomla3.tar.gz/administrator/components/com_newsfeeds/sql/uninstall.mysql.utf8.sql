DROP TABLE IF EXISTS `#__newsfeeds`;

